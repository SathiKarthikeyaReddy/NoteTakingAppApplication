package com.example.note_taking_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoteTakingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoteTakingAppApplication.class, args);
	}

}
